package util;

public class Utilities {

	public static Object swap(Object o1, Object o2) {
		
		//TODO: implement
		return null;
	}

}

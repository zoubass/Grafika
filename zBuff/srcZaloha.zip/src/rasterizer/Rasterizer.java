package rasterizer;

import java.awt.image.BufferedImage;

import transforms.Point2D;
import transforms.Vec3D;

public interface Rasterizer {

	void drawTriangle(Vec3D v1, Vec3D v2, Vec3D v3,Point2D t1, Point2D t2, Point2D t3, BufferedImage texture);
	
	void clear();
}

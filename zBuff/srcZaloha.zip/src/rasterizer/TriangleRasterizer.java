package rasterizer;

import java.awt.image.BufferedImage;

import transforms.Point2D;
import transforms.Vec3D;

public class TriangleRasterizer implements Rasterizer {
	private final BufferedImage img;
	private final double[][] depth;

	public TriangleRasterizer(BufferedImage img) {
		this.img = img;
		this.depth = new double[img.getHeight()][img.getWidth()];

	}

	public void drawTriangle(Vec3D v1, Vec3D v2, Vec3D v3, Point2D t1, Point2D t2, Point2D t3, BufferedImage texture) {

		// v1
		if (v2.y < v1.y) {
			Vec3D pom = v2;
			v2 = v1;
			v1 = pom;

			Point2D pom2 = t2;
			t2 = t1;
			t1 = pom2;
		}

		if (v3.y < v2.y) {
			Vec3D pom = v3;
			v3 = v2;
			v2 = pom;

			Point2D pom2 = t3;
			t3 = t1;
			t1 = pom2;
		}

		if (v2.y < v1.y) {
			Vec3D pom = v2;
			v2 = v1;
			v1 = pom;

			Point2D pom2 = t3;
			t3 = t2;
			t2 = pom2;
		}

		// P�iprava pro perspektivn� korektn� interpolaci
		Point2D t3Pom = new Point2D(t3.getX() / v3.getZ(), t3.getY() / v3.getZ());
		Point2D t2Pom = new Point2D(t2.getX() / v2.getZ(), t2.getY() / v2.getZ());
		Point2D t1Pom = new Point2D(t1.getX() / v1.getZ(), t1.getY() / v1.getZ());

		// prvni polovina trojuhelniku
		for (int y = Math.max((int) v1.getY() + 1, 0); y <= Math.min(v2.getY(), img.getHeight() - 1); y++) {
			double ta = (y - v1.getY()) / (v2.getY() - v1.getY());
			double tb = (y - v1.getY()) / (v3.getY() - v1.getY());

			Vec3D va = v2.mul(ta).add(v1.mul(1 - ta));
			Vec3D vb = v3.mul(tb).add(v1.mul(1 - tb));

			Point2D taInt = t2Pom.mul(ta).add(t1Pom.mul(1 - ta));
			Point2D tbInt = t3Pom.mul(tb).add(t1Pom.mul(1 - tb));

			// zaridit xa <= xb (pozor na roztrhani vrcholu)
			if (vb.getX() < va.getX()) {
				Vec3D pom = va;
				va = vb;
				vb = pom;

				Point2D pom2 = taInt;
				taInt = tbInt;
				tbInt = pom2;
			}
			setDepthOnInterval(y, va, vb, taInt, tbInt, texture);
		}
		// druha polovina trojuhelniku
		for (int y = Math.max((int) v2.getY() + 1, 0); y <= Math.min(v3.getY(), img.getHeight() - 1); y++) {
			double ta = (y - v2.getY()) / (v3.getY() - v2.getY());
			double tb = (y - v1.getY()) / (v3.getY() - v1.getY());

			Vec3D va = v3.mul(ta).add(v2.mul(1 - ta));
			Vec3D vb = v3.mul(tb).add(v1.mul(1 - tb));

			Point2D taInt = t3Pom.mul(ta).add(t2Pom.mul(1 - ta));
			Point2D tbInt = t3Pom.mul(tb).add(t1Pom.mul(1 - tb));

			if (vb.getX() < va.getX()) {
				Vec3D pom = va;
				va = vb;
				vb = pom;

				Point2D pom2 = taInt;
				taInt = tbInt;
				tbInt = pom2;
			}
			setDepthOnInterval(y, va, vb, taInt, tbInt, texture);
		}
	}

	private void setDepthOnInterval(int y, Vec3D va, Vec3D vb, Point2D taInt, Point2D tbInt, BufferedImage texture) {
		for (int x = Math.max((int) va.getX() + 1, 0); x <= Math.min(vb.getX(), img.getWidth() - 1); x++) {
			double t = (x - vb.getX()) / (va.getX() - vb.getX());
			Vec3D v = va.mul(1 - t).add(vb.mul(t));
			Point2D texelPom = taInt.mul(1 - t).add(tbInt.mul(t));

			Point2D texel = new Point2D(texelPom.getX() * v.getZ(), texelPom.getY() * v.getZ());
			if (depth[y][x] > v.getZ()) {

				int tx = (int) (texel.getX() % 255);
				int ty = (int) (texel.getY() % 255);

				img.setRGB(x, y, texture.getRGB(Math.abs(tx), Math.abs(ty)));
				depth[y][x] = v.getZ();
			}
		}
	}

	public void clear() {
		for (int i = 0; i < img.getHeight(); i++) {
			for (int j = 0; j < img.getWidth(); j++) {
				depth[i][j] = 1.0;
			}
		}

	}
}

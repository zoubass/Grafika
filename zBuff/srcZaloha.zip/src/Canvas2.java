import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import model.Cube;
import model.CubeTri;
import model.Pyramid;
import model.Solid;
import rasterizer.Rasterizer;
import rasterizer.TriangleRasterizer;
import renderer.Renderer;
import renderer.RendererTri;
import transforms.Camera;
import transforms.Mat4;
import transforms.Mat4PerspRH;
import transforms.Mat4Transl;
import transforms.Vec3D;

public class Canvas2 {

	private /* @NotNull */ JFrame frame;
	private /* @NotNull */ JPanel panel;
	private /* @NotNull */ BufferedImage img;
	private double x;
	private double y;

	private final Solid cube;
	private final Solid pyramid;
	private final Rasterizer triaRasterizer;
	private final Renderer triaRenderer;
	private final Camera camera = new Camera();
	private final Mat4 persp;

	public Canvas2(int width, int height) throws IOException {
		frame = new JFrame();
		frame.setTitle("UHK FIM PGRF : Canvas");
		frame.setResizable(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		img = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

		persp = new Mat4PerspRH(Math.PI / 3, (double) img.getHeight() / img.getWidth(), 1, 40);

		triaRasterizer = new TriangleRasterizer(img);
		triaRenderer = new RendererTri(triaRasterizer, width, height);
		panel = new JPanel();
		panel.setPreferredSize(new Dimension(width, height));

		pyramid = new Pyramid(ImageIO.read(new File("sachovnice.jpg")));
		cube = new CubeTri(new Cube(), ImageIO.read(new File("sachovnice.gif")));

		frame.add(panel);
		frame.pack();
		frame.setVisible(true);

		// camera setting
		camera.setPosition(new Vec3D(15, 4, 3));
		camera.setZenith(-Math.atan(15.0 / (20.0 * Math.sqrt(2.0))));
		camera.setAzimuth(5 * Math.PI / 4);

		// setting up key and mouse listeners
		inputHandlersSetUp();

		panel.setFocusable(true);
		panel.requestFocusInWindow();

	}

	public void clear(int color) {
		Graphics gr = img.getGraphics();
		gr.setColor(new Color(color));
		gr.fillRect(0, 0, img.getWidth(), img.getHeight());
	}

	public void present() {
		if (panel.getGraphics() != null)
			panel.getGraphics().drawImage(img, 0, 0, img.getWidth(), img.getHeight(), null);
	}

	public void draw() {
		clear(0x000000);

		// clearing zBuff
		triaRasterizer.clear();
		triaRenderer.render(cube.getVertices(), cube.getIndices(), cube.getTexels(), cube.getTextureImg(),
				new Mat4Transl(10, 0, 0).mul(camera.getViewMatrix()).mul(persp));

//		triaRenderer.render(pyramid.getVertices(), pyramid.getIndices(), pyramid.getTexels(), pyramid.getTextureImg(),
//				new Mat4Transl(10, -1.5, 0).mul(camera.getViewMatrix()).mul(persp));

	}

	public void start() {
		draw();
		present();
	}

	public static void main(String[] args) {
		try {
			Canvas2 canvas = new Canvas2(800, 600);
			SwingUtilities.invokeLater(() -> {
				SwingUtilities.invokeLater(() -> {
					SwingUtilities.invokeLater(() -> {
						SwingUtilities.invokeLater(() -> {
							canvas.start();
						});
					});
				});
			});
		} catch (IOException e) {
			System.err.println("Failed to load image texture.");
		}

	}

	private void inputHandlersSetUp() {
		class MouseHandler extends MouseAdapter {
			@Override
			public void mousePressed(MouseEvent e) {
				x = e.getX();
				y = e.getY();
			}

			@Override
			public void mouseDragged(MouseEvent e) {
				camera.addAzimuth((Math.PI / 1000) * (x - e.getX()));
				camera.addZenith((Math.PI / 1000) * (y - e.getY()));
				x = e.getX();
				y = e.getY();
				start();
			}
		}
		MouseHandler mouseHandler = new MouseHandler();
		panel.addMouseListener(mouseHandler);
		panel.addMouseMotionListener(mouseHandler);

		panel.addKeyListener(new KeyAdapter() {

			public void keyPressed(KeyEvent e) {
				switch (e.getKeyCode()) {
				case KeyEvent.VK_W:
					camera.forward(0.5);
					break;
				case KeyEvent.VK_S:
					camera.backward(0.5);
					break;
				case KeyEvent.VK_A:
					camera.left(0.5);
					break;
				case KeyEvent.VK_D:
					camera.right(0.5);
					break;
				default: // TODO: ?
					break;
				}
				start();
			}
		});
	}

}
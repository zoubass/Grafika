package renderer;

import java.awt.image.BufferedImage;
import java.util.List;

import transforms.Mat4;
import transforms.Point2D;
import transforms.Point3D;

public interface Renderer {

	public void render(List<Point3D> vertices, List<Integer> indices, List<Point2D> texels,BufferedImage texture,Mat4 mat);

}

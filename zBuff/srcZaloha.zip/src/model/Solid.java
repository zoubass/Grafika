package model;

import java.awt.image.BufferedImage;
import java.util.List;

import transforms.Point2D;
import transforms.Point3D;

public interface Solid {
	List<Point3D> getVertices();

	List<Integer> getIndices();

	List<Point2D> getTexels();

	BufferedImage getTextureImg();

	// TODO: Zamyslet se nad strutkurou
}
